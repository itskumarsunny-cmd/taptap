require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

// ── MIDDLEWARE ──────────────────────────────────────────────
app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '../public')));

// ── DATABASE ─────────────────────────────────────────────────
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/randochat')
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.log('⚠️  MongoDB not connected (running without DB):', err.message));

// ── USER MODEL ───────────────────────────────────────────────
const userSchema = new mongoose.Schema({
  username:  { type: String, required: true, unique: true, trim: true, minlength: 3, maxlength: 20 },
  email:     { type: String, required: true, unique: true, lowercase: true },
  password:  { type: String, required: true },
  avatar:    { type: String, default: '' },
  createdAt: { type: Date, default: Date.now },
  lastSeen:  { type: Date, default: Date.now },
  chatCount: { type: Number, default: 0 },
  isBanned:  { type: Boolean, default: false }
});

const User = mongoose.model('User', userSchema);

// ── AUTH HELPERS ─────────────────────────────────────────────
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_in_production';

function signToken(userId) {
  return jwt.sign({ id: userId }, JWT_SECRET, { expiresIn: '7d' });
}

function verifyToken(token) {
  try { return jwt.verify(token, JWT_SECRET); } catch { return null; }
}

function authMiddleware(req, res, next) {
  const token = req.cookies?.token || req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Not authenticated' });
  const decoded = verifyToken(token);
  if (!decoded) return res.status(401).json({ error: 'Invalid token' });
  req.userId = decoded.id;
  next();
}

// ── AUTH ROUTES ──────────────────────────────────────────────

// Register
app.post('/api/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password)
      return res.status(400).json({ error: 'All fields are required' });
    if (password.length < 6)
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    if (username.length < 3)
      return res.status(400).json({ error: 'Username must be at least 3 characters' });

    const exists = await User.findOne({ $or: [{ email }, { username }] });
    if (exists) {
      if (exists.email === email.toLowerCase()) return res.status(400).json({ error: 'Email already registered' });
      return res.status(400).json({ error: 'Username already taken' });
    }

    const hashed = await bcrypt.hash(password, 12);
    const user = await User.create({ username, email, password: hashed });

    const token = signToken(user._id);
    res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000, sameSite: 'lax' });
    res.json({ success: true, user: { id: user._id, username: user.username, email: user.email } });
  } catch (err) {
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
});

// Login
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(401).json({ error: 'Invalid email or password' });
    if (user.isBanned) return res.status(403).json({ error: 'Account suspended' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'Invalid email or password' });

    user.lastSeen = new Date();
    await user.save();

    const token = signToken(user._id);
    res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000, sameSite: 'lax' });
    res.json({ success: true, user: { id: user._id, username: user.username, email: user.email } });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Logout
app.post('/api/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ success: true });
});

// Get current user
app.get('/api/me', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ user });
  } catch {
    res.status(500).json({ error: 'Server error' });
  }
});

// Live stats
app.get('/api/stats', (req, res) => {
  res.json({ onlineUsers: onlineUsers.size, waitingUsers: waitingQueue.length });
});

// Short-lived socket auth token (used by chat.html to authenticate socket.io connection)
app.get('/api/socket-token', authMiddleware, (req, res) => {
  const token = signToken(req.userId);
  res.json({ token });
});

// ── PAGE ROUTES ──────────────────────────────────────────────
app.get('/', (req, res) => res.sendFile(path.join(__dirname, '../public/index.html')));
app.get('/chat', (req, res) => res.sendFile(path.join(__dirname, '../public/chat.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, '../public/login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, '../public/register.html')));

// ── MATCHMAKING STATE ────────────────────────────────────────
const onlineUsers  = new Map();   // socketId → { userId, username, mode }
const waitingQueue = [];          // [{ socketId, mode, userId, username }]
const activePairs  = new Map();   // socketId → partnerSocketId

// ── SOCKET.IO ────────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`🔌 Socket connected: ${socket.id}`);

  // ── AUTH on socket ──
  socket.on('authenticate', ({ token }) => {
    const decoded = verifyToken(token);
    if (!decoded) {
      socket.emit('auth-error', 'Invalid token. Please log in again.');
      return;
    }
    User.findById(decoded.id).select('-password').then(user => {
      if (!user || user.isBanned) {
        socket.emit('auth-error', 'Account not found or suspended.');
        return;
      }
      onlineUsers.set(socket.id, { userId: user._id.toString(), username: user.username, mode: null });
      socket.emit('authenticated', { username: user.username });
      broadcastStats();
    }).catch(() => socket.emit('auth-error', 'Server error.'));
  });

  // ── JOIN QUEUE ──
  socket.on('find-partner', ({ mode }) => {
    const me = onlineUsers.get(socket.id);
    if (!me) { socket.emit('error', 'Not authenticated'); return; }

    // Don't queue if already paired
    if (activePairs.has(socket.id)) return;

    me.mode = mode || 'video';

    // Check if someone waiting with same mode
    const idx = waitingQueue.findIndex(w => w.mode === me.mode && w.socketId !== socket.id);

    if (idx !== -1) {
      // Match found!
      const partner = waitingQueue.splice(idx, 1)[0];

      activePairs.set(socket.id, partner.socketId);
      activePairs.set(partner.socketId, socket.id);

      // Tell both who they're paired with
      socket.emit('partner-found', {
        partnerName: partner.username,
        isInitiator: true,
        mode: me.mode
      });

      io.to(partner.socketId).emit('partner-found', {
        partnerName: me.username,
        isInitiator: false,
        mode: me.mode
      });

      // Update chat counts
      User.findByIdAndUpdate(me.userId, { $inc: { chatCount: 1 } }).catch(() => {});
      User.findByIdAndUpdate(partner.userId, { $inc: { chatCount: 1 } }).catch(() => {});

      console.log(`✅ Matched: ${me.username} ↔ ${partner.username} [${me.mode}]`);
    } else {
      // Add to waiting queue
      waitingQueue.push({ socketId: socket.id, mode: me.mode, userId: me.userId, username: me.username });
      socket.emit('waiting');
      console.log(`⏳ ${me.username} waiting [${me.mode}] — queue: ${waitingQueue.length}`);
    }

    broadcastStats();
  });

  // ── WebRTC SIGNALING ──
  socket.on('webrtc-offer', ({ offer }) => {
    const partnerId = activePairs.get(socket.id);
    if (partnerId) io.to(partnerId).emit('webrtc-offer', { offer });
  });

  socket.on('webrtc-answer', ({ answer }) => {
    const partnerId = activePairs.get(socket.id);
    if (partnerId) io.to(partnerId).emit('webrtc-answer', { answer });
  });

  socket.on('webrtc-ice', ({ candidate }) => {
    const partnerId = activePairs.get(socket.id);
    if (partnerId) io.to(partnerId).emit('webrtc-ice', { candidate });
  });

  // ── TEXT MESSAGE ──
  socket.on('chat-message', ({ text }) => {
    const me = onlineUsers.get(socket.id);
    const partnerId = activePairs.get(socket.id);
    if (!me || !partnerId || !text) return;
    const clean = String(text).substring(0, 500);
    io.to(partnerId).emit('chat-message', { text: clean, from: me.username });
  });

  // ── SKIP / DISCONNECT FROM PARTNER ──
  socket.on('skip', () => disconnectPair(socket.id, 'skip'));

  // ── REPORT ──
  socket.on('report', ({ reason }) => {
    const partnerId = activePairs.get(socket.id);
    const me = onlineUsers.get(socket.id);
    console.log(`🚩 REPORT by ${me?.username}: socket ${partnerId}, reason: ${reason}`);
    // In production: save report to DB
    disconnectPair(socket.id, 'skip');
  });

  // ── DISCONNECT ──
  socket.on('disconnect', () => {
    disconnectPair(socket.id, 'disconnect');
    onlineUsers.delete(socket.id);

    // Remove from waiting queue
    const qi = waitingQueue.findIndex(w => w.socketId === socket.id);
    if (qi !== -1) waitingQueue.splice(qi, 1);

    broadcastStats();
    console.log(`❌ Socket disconnected: ${socket.id}`);
  });

  // ── HELPER: disconnect a pair ──
  function disconnectPair(socketId, reason) {
    const partnerId = activePairs.get(socketId);
    if (partnerId) {
      activePairs.delete(socketId);
      activePairs.delete(partnerId);
      io.to(partnerId).emit('partner-left', { reason });
      console.log(`🔀 Pair broken: ${socketId} ↔ ${partnerId} [${reason}]`);
    }
  }

  // ── HELPER: broadcast live stats ──
  function broadcastStats() {
    io.emit('stats-update', { onlineUsers: onlineUsers.size, waitingUsers: waitingQueue.length });
  }
});

// ── START SERVER ─────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 RandoChat server running on http://localhost:${PORT}`);
});
